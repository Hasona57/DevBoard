# Developer Advent TUI

A terminal-based developer advent calendar build with Python and Textual.

## Features
- 24 real advent days
- Daly unlocks
- Developer Challenges each day
- Keyboard shortcuts
- progress tracking